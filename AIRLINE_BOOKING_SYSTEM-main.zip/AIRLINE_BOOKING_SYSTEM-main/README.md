# AIRLINE_BOOKING_SYSTEM

**DESCRIPTION**

This AIRLINE BOOKING SYSTEM is an online web application specifically designed for booking flight tickets.




**TECHNOLOGIES USED**

**Frontend:** HTML,CSS

**Backend:** JavaScript




**FEATURES:**

Destinations

Departure and Return date picker

Trip (One way/Round)

Order confirmation details 




**HOW TO USE**

**Step 1-**     Download or clone all the project repository source code files (suggested VScode).

**Step 2-**     Save all the source code files after cloning at one workspace/folder.

**Step-3**      Open the downmost index.html file on your browser.





**OWNERSHIP** AND **DEVELOPMENT:**

 **ⓒ** **TEAM DELTA LNCTU**


 
